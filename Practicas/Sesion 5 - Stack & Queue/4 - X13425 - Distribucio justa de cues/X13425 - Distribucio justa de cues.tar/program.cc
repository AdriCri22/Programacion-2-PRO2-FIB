#include "CuaIOParInt.hh"
using namespace std;

int main() {
    queue<ParInt> cua;
    llegirCuaParInt(cua);
    
    queue<ParInt> cua1;
    queue<ParInt> cua2;
    int temps1 = 0;
    int temps2 = 0;
  
    while (not cua.empty()) {
        if (temps1 <= temps2) {
            cua1.push(cua.front());
            temps1 += cua.front().segon();
        } else {
            cua2.push(cua.front());
            temps2 += cua.front().segon();
        }
        cua.pop();
    }
    
    escriureCuaParInt(cua1);
    cout << endl;
    escriureCuaParInt(cua2);
}
