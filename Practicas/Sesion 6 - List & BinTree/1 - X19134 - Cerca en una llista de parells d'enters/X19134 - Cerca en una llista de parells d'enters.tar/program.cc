#include "LlistaIOParInt.hh"
#include <iostream>
#include <list>
using namespace std;

int main() {
    list<ParInt> l;
    list<ParInt>::const_iterator it;
    LlegirLlistaParInt(l);
    
    int n;
    cin >> n;
    
    int count = 0;
    int sum = 0;
    for (it = l.begin(); it != l.end(); it++) {
        if ((*it).primer() == n) {
            count++;
            sum += (*it).segon();
        }
    }
    
    cout << n << " " << count << " " << sum << endl;
}
