#include "LlistaIOEstudiant.hh"

// Pre: l és buida; el canal estandar d’entrada conté parelles
// de valors <enter, double>, acabat per un parell 0 0
// Post: s’han afegit al final de l els estudiants llegits fins al 0 0 (no inclòs)
void LlegirLlistaEstudiant(list<Estudiant>& l) {
    list<Estudiant>::iterator it = l.begin();
    Estudiant est;
    est.llegir();
    while (est.consultar_DNI() != 0) {
        l.insert(it, est);
        est.llegir();
    }        
}

// Pre: cert
// Post: s’han escrit al canal estandar de sortida els elements de l
void EscriureLlistaEstudiant(const list<Estudiant>& l) {
    list<Estudiant>::const_iterator it = l.begin();
    while (it != l.end()) {
        (*it).escriure();
        it++;
    }
    cout << endl;
}
