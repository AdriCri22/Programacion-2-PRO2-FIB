#ifndef SOLUTION_HH
#define SOLUTION_HH
#include "Estudiant.hh"
#include <list>

void esborra_tots(list<Estudiant> &t, int x);

#endif
