#include "BinTreeIOParInt.hh"
using namespace std;

int find(const BinTree<ParInt>& a, int n, int& c) {
    if (not a.empty()) {
        if (a.value().primer() == n) {
            c = a.value().segon();
            return 0;
        }
        int left = find(a.left(), n, c);
        if (left != -1) return 1 + left;
        int right = find(a.right(), n, c);
        if (right != -1) return 1 + right;
    }
    return -1;
}

int main() {
    BinTree<ParInt> a;
    read_bintree_parint(a);
    
    int n, c;
    while (cin >> n) {
        int d = find(a, n, c);
        if (d != -1) cout << n << " " << c << " " << d << endl;
        else cout << d << endl;
    }
}
