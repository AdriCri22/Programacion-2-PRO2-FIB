/** @file Cjt_clusters.hh
    @brief Especificación de la clase Cjt_clusters
*/

#ifndef CONJ_CLU_HH
#define CONJ_CLU_HH

#include "Cluster.hh"
#include "Tabla.hh"

#ifndef NO_DIAGRAM	//No aparece en el diagrama
#include <map>
#endif

/*
 * Clase Cjt_clusters
 */

/** @class Cjt_clusters
    @brief Representa un conjunto de clústers.
    
    Sus operaciones son las modificadoras crean clusters, borran el 
    conjunto, inicializan la tabla de distancias (copiandola de la tabla de 
    distancias del conjunto de especies), ejecuta el paso WPGMA e imprime 
    el arbol filogenético. Las consultoras permiten obtener el número de 
    clústers del conjunto, imprime los clústers del conjunto e imprime la 
    tabla de distancias.
*/
class Cjt_clusters {
    // Descripción: contiene un conjunto de clústers junto a una tabla 
    //              de distancias entre estos
private:
    /* El conjunto de clústers se guardan en un map ordenado por 
       identificador para facilitar la búsquedas y la impresión de las 
       especies, la tabla de distancias es una clase dónde las distancias
       se fusionando a medida que ejecutamos el paso WPGMA. */
    
             /*     Variables privadas     */
    /** @brief map de que contiene los clústers.*/
    map<string, Cluster> mclu;

    /** @brief Tabla de distancias entre especies.*/
    Tabla tabla;

public:
             /*     Constructoras     */
    /** @brief Constructora vacía.
        \pre Cierto.
        \post Crea un conjunto de clústers vacío.
    */
    Cjt_clusters();

    	       /*     Modificadoras     */
    /** @brief Borra todos los clústers del conjunto.
        \pre Cierto.
        \post Vacía el map del conjunto de clústers.
    */
    void borra_clusters();

    /** @brief Añade un clúster al conjunto con el identificador dado y 
               distancia 0.
        \pre Cierto.
        \post Añade al map del conjunto clusters un nuevo clúster
              con el identificador dado y distancia 0.
    */
    void crea_cluster(const string& id);

    /** @brief Copia la tabla de distancias del conjunto especies.
        \pre Cierto.
        \post Copia las tabla de distancias del conjunto especies a la 
              tabla de distancias del conjunto clústers.
    */
    void inicializa_distancias(const Tabla& tabla_esp);

    /** @brief Ejecuta un paso del algoritmo WPGMA e imprime la tabla de
               distancias
        \pre Cierto
        \post Ejecuta un paso del algoritmo WPGMA e imprime la tabla de
              distancias entre clústers resultante.
    */
    void ejecuta_paso_wpgma();

    /** @brief Imprime el árbol filogenético para el conjunto de especies
               actual.
        \pre Cierto.
        \post Imprime el árbol que agrupa todas las especies, resultante
              de aplicar el algoritmo WPGMA.
    */
    void imprime_arbol_filogenetico();

    	       /*     Consultoras     */
    /** @brief Devuelve el número de clústers que hay en el conjunto.
        \pre Cierto.
        \post Devuelve un int con el número de clústers en el conjunto.
    */
    int numero_clusters() const;

    /** @brief Imprime el clúster a partir de un identificador si este 
               existe.
        \pre Cierto.
        \post Imprime el clúster con el identificador dado por el canal
              estándar de salida si existe y devuelve el bool cierto, en
              caso contrario el bool sera falso.
    */
    bool imprime_cluster(string id) const;

    	       /*     Lectura y Escritura     */
    /** @brief Imprime la tabla de distancias entre clústers.
        \pre Cierto.
        \post Imprime la tabla de distancias entre clústers por el canal
              estándar de salida.
    */
    void imprime_distancia_clusters() const;

private:
    	       /*     Lectura y Escritura     */
    /** @brief Ejecuta el paso wpgma.
        \pre Cierto.
        \post Borra del conjunto clústers los clústers con distancia mínima
              y crea un nuevo clúster como combinación de estos y modifica
              la tabla de distancias.
    */
    static void paso_wpgma(map<string, Cluster>& clus, Tabla& tab);
    
};
#endif
