/** @file Cluster.hh
    @brief Especificación de la clase Cluster
*/

#ifndef CLU_HH
#define CLU_HH

#include "ParData.hh"

#ifndef NO_DIAGRAM	//No aparece en el diagrama
#include "BinTree.hh"
#endif

/*
 * Clase Cluster
 */

/** @class Cluster
    @brief Representa un clúster a partir de una especie o varios clústers.
    
    Sus operaciones permiten crear clústers para el conjunto de clústers, 
    un clúster se crea mediante una estructura arbolescente con un 
    identificador y una distancia dados. También se ofrece la escritura de 
    la estructura arbolescente.
*/

class Cluster {
    /* Descripción: contiene clúster mediante una estrucutra arborescente 
                    que está formada por una especie, con el identificador 
                    de esta y distancia 0, o un par de clústers dados. */
private:    
             /*     Variables privadas     */
     /** @brief Árbol formado por el ParData que contiene el identificador
                y la distancia*/
     BinTree<ParData> a;

public:
             /*     Constructoras     */
    /** @brief Constructora vacía.
        \pre Cierto.
        \post Crea un clúster vacío.
    */
    Cluster();

    /** @brief Constructora con identificador y gen.
	      \pre Cierto.
	      \post El clúster tiene el identificador dado y distancia 0.
    */
    Cluster(const string& id);

    /** @brief Constructora de pares de clústers.
	      \pre Cierto.
	      \post El resultado es un clúster formado por un par de clústers 
                junto con la distancia, el identificador pasa a ser ab donde 
                a < b y la hoja izquierda es a y la derecha es b.
    */
    Cluster(Cluster cluA, Cluster cluB, double dist);

    	       /*     Lectura y Escritura     */
    /** @brief Imprime un clúster.
	      \pre Cierto.
	      \post Imprime un clúster por el canal de salida estándar.
    */
    void imprime_arbol() const;

    /** @brief Imprime las hojas izquierda y derecha del árbol.
	      \pre Cierto.
	      \post Imprime las hojas izquierda y derecha del árbol por el canal
              de salida estándar.
    */
    void imprime_hojas(const BinTree<ParData>& b) const;
};

#endif
