/** @file Cjt_especies.hh
    @brief Especificación de la clase Cjt_especies
*/

#ifndef CONJ_ESP_HH
#define CONJ_ESP_HH

#include "Cjt_clusters.hh"
#include "Tabla.hh"
#include "Especie.hh"

/*
 * Clase Cjt_especies
 */

/** @class Cjt_especies
    @brief Representa un conjunto de especies.
    
    Sus operaciones son las modificadoras del parámetro k definido al 
    inicio del programa, la creación y eliminación de especies del conjunto
    y inicializa los clusters reinicializando estos y traspasando las 
    especies y la tabla. Las consultoras permiten obtener el número de 
    especies del conjunto, consultar el gen de una especie, saber si una 
    especie existe, la distancia entre 2 especies. La lectura (que provoca 
    la reinicialización) del conjunto, la esctitura del conjunto y la 
    escritura de la tabla de distancias.
*/

class Cjt_especies {
    /* Descripción: contiene un conjunto de especies junto a una tabla 
                    de distancias entre estas */
private:
    /* El conjunto de especies se guardan en un map ordenado por 
       identificador para facilitar la búsquedas y la impresión de las 
       especies, la tabla de distancias es una clase dónde las distancias
       se van agregando en función de su llegada y borrando si la especie
       es eliminada.
       El parámetro k se define al principio del programa y sirve para 
       contruir los k-meros de las especies. */
    
             /*     Variables privadas     */
    /** @brief Parámetro k para calcular las distancias.*/
    int k;

    /** @brief map que contiene el conjunto de especies.*/
    map<string, Especie> mesp;

    /** @brief Tabla de distancias entre especies.*/
    Tabla tabla;

public:

             /*     Constructoras     */
    /** @brief Constructora vacía.
        \pre Cierto.
        \post Crea un conjunto de especies vacío.
    */
    Cjt_especies();

    	       /*     Modificadoras     */
    /** @brief Obtiene el parámetro k.
        \pre Cierto.
        \post Obtiene parámetro k para los k-meros.
    */
    void obtener_k();

    /** @brief Traspasa las especies a clústers
        \pre Cierto.
        \post Modifica el conjunto de clústers, borrando los clústers 
              actuales y creando clústers de nuevos a partir de las 
              especies existentes en el conjunto especies. 
              Además copia la tabla de distancias del conjunto especies al 
              conjunto clústers.
    */
    void ini_clusters(Cjt_clusters& cjt_clu);

    /** @brief Crea una especie con un identificador y un gen dados.
        \pre Cierto.
        \post Se agrega al map del conjunto especies una especie.
    */
    void crea_especie(const string& id, const string& gen);

    /** @brief Devuelve una especie del conjunto.
        \pre Cierto.
        \post Elimina del map del conjunto especies la especie con el 
              identificador dado.
    */
    void elimina_especie(const string& id);

    	       /*     Consultoras     */
    /** @brief Devuelve el número de especies
       \pre Cierto.
       \post Devuelve un int con el número de especies en el conjunto.
    */
    int numero_especies() const;

    /** @brief Devuelve el gen de una especie del conjunto a partir de su 
               identificador.
        \pre Cierto.
        \post Devuelve un string con el gen asociado a la especie.
    */
    string obtener_gen(const string& id) const;

    /** @brief Devuelve la distancia entre dos especies.
        \pre Cierto.
        \post Devuelve un double de la distancia entre las dos especies.
    */
    double distancia(const string& idA, const string& idB) const;

    /** @brief Comprueba si una especie existe en el conjunto.
        \pre Cierto.
        \post Devuelve un bool de si dicha especie existe en el conjunto.
    */
    bool exitse_especie(const string& id) const;

    	       /*     Lectura y Escritura     */
    /** @brief Lectura de un conjunto de especies.
        \pre Cierto.
        \post El parámetro implícito contiene el conjunto de especies leído
              del canal estándar de entrada siempre que no se repita.
    */
    void lee_cjt_especies();

    /** @brief Impresión del conjunto de especies.
        \pre Cierto.
        \post Escribe por el canal estándar de entrada las especies
              del conjunto que contiene el parámetro implícito.
    */
    void imprime_cjt_especies() const;

    /** @brief Imprime la tabla de distancias.
        \pre Cierto.
        \post Imprime la tabla de distancias entre cada par de especies del
              conjunto de especies por el canal estándar de salida.
              Si el conjunto esta vacío, no imprime ninguna información.
    */
    void tabla_distancias() const;

private:
        		     /*     Funciones privadas     */
    /** @brief Añade distancias a la tabla de distancias entre especies.
	     \pre Cierto.
	     \post Añade una o varias distancias a la clase Tabla al añadir una
               nueva especie.
    */
    static void agregar_distancia(Tabla& tab, const map<string, Especie>& especies, const string& id, const Especie& esp);

    /** @brief Elimina distancias a la tabla de distancias entre especies.
	     \pre Cierto.
	     \post Elimina una o varias distancias de la clase Tabla dado un 
               identificador.
    */
    static void eliminar_distancia(Tabla& tab, const map<string, Especie>& especies, const string& id);

};
#endif
