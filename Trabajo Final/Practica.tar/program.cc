/** @mainpage

        El programa principal se encuentra en el módulo program.cc.
        Atendiendo a los tipos de datos sugeridos en el enunciado,
        necesitaremos un módulo para representar el conjunto de especies,
        en el que cada especie será representado mediante un identificador
        y un gen, otro para el conjunto de clústers, el cual es una cópia
        de las especies dónde se irán combinando las diferentes especies en
        función del algoritmo WPGMA. Las tablas de distancias entre
        especies y/o entre clústers está definida dentro del conjunto
        (especies y clústers).
 */

/** @file program.cc
    @brief Programa princial.

    Suponemos que los datos leídos son siempre correctos, ya que no
    incluimos combrobaciones al respecto.  Para acceder a las opciones
    disponibles usaremos comandos.
*/

#include "Cjt_especies.hh"
#include "Cjt_clusters.hh"

#ifndef NO_DIAGRAM      //No aparece en el diagrama
#include <iostream>
using namespace std;
#endif

int main() {
    Cjt_especies cjt_esp;
    Cjt_clusters cjt_clu;
    cjt_esp.obtener_k();

    string comando;
    cin >> comando;

    while (comando != "fin") {
        if (comando == "crea_especie") {
            string id, gen;
            cin >> id >> gen;
            cout << "# crea_especie " << id << ' ' << gen << endl;
            if (not cjt_esp.exitse_especie(id))
                cjt_esp.crea_especie(id, gen);
            else
                cout << "ERROR: La especie " << id << " ya existe." << endl;
        }

        else if (comando == "obtener_gen") {
            string id;
            cin >> id;
            cout << "# obtener_gen " << id << endl;
            if (cjt_esp.exitse_especie(id))
                cout << cjt_esp.obtener_gen(id) << endl;
            else
                cout << "ERROR: La especie " << id << " no existe." << endl;
        }

        else if (comando == "distancia") {
            string idA, idB;
            cin >> idA >> idB;
            cout << "# distancia " << idA << ' ' << idB << endl;
            if (idA == idB) {
                if (cjt_esp.exitse_especie(idA))
                    cout << 0 << endl;
                else
                    cout << "ERROR: La especie " << idA << " no existe." << endl;
            } else {
                if (cjt_esp.exitse_especie(idA) and cjt_esp.exitse_especie(idB))
                    cout << cjt_esp.distancia(idA, idB) << endl;
                else if (not cjt_esp.exitse_especie(idA) and not cjt_esp.exitse_especie(idB))
                    cout << "ERROR: La especie " << idA << " y la especie " << idB << " no existen." << endl;
                else if (not cjt_esp.exitse_especie(idA))
                    cout << "ERROR: La especie " << idA << " no existe." << endl;
                else
                    cout << "ERROR: La especie " << idB << " no existe." << endl;
            }
        }

        else if (comando == "elimina_especie") {
            string id;
            cin >> id;
            cout << "# elimina_especie " << id << endl;
            if (cjt_esp.exitse_especie(id))
                cjt_esp.elimina_especie(id);
            else
                cout << "ERROR: La especie " << id << " no existe." << endl;
        }

        else if (comando == "existe_especie") {
            string id;
            cin >> id;
            cout << "# existe_especie " << id << endl;
            if (cjt_esp.exitse_especie(id))
                cout << "SI" << endl;
            else
                cout << "NO" << endl;
        }

        else if (comando == "lee_cjt_especies")  {
            cout << "# lee_cjt_especies" << endl;
            cjt_esp.lee_cjt_especies();
        }

        else if (comando == "imprime_cjt_especies") {
            cout << "# imprime_cjt_especies" << endl;
            cjt_esp.imprime_cjt_especies();
        }

        else if (comando == "tabla_distancias") {
            cout << "# tabla_distancias" << endl;
            cjt_esp.tabla_distancias();
        }

        else if (comando == "inicializa_clusters") {
            cout << "# inicializa_clusters" << endl;
            cjt_esp.ini_clusters(cjt_clu);
            cjt_clu.imprime_distancia_clusters();
        }

        else if (comando == "ejecuta_paso_wpgma") {
            cout << "# ejecuta_paso_wpgma" << endl;
            if (cjt_clu.numero_clusters() > 1)
                cjt_clu.ejecuta_paso_wpgma();
            else
                cout << "ERROR: num_clusters <= 1" << endl;
        }

        else if (comando == "imprime_cluster") {
            string id;
            cin >> id;
            cout << "# imprime_cluster " << id << endl;
            if (cjt_clu.imprime_cluster(id))
                cout << endl;
            else
                cout << "ERROR: El cluster " << id << " no existe." << endl;
        }

        else if (comando == "imprime_arbol_filogenetico") {
            cout << "# imprime_arbol_filogenetico" << endl;
            if (cjt_esp.numero_especies() != 0) {
                cjt_esp.ini_clusters(cjt_clu);
                cjt_clu.imprime_arbol_filogenetico();
            } else
                cout << "ERROR: El conjunto de clusters es vacio." << endl;
        }
        cout << endl;
        cin >> comando;
    }
}
