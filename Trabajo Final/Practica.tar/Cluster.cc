/** @file Cluster.cc
    @brief Código de la clase Cluster.
*/

#include "Cluster.hh"

             /*     Constructoras     */
/* Constructora de un clúster vacío */
Cluster::Cluster() {}

/* Constructora de un clúster con un identificador y distancia 0 */
Cluster::Cluster(const string& id) {
    a = BinTree<ParData>(ParData(id, 0));
}

/* Constructora de un clúster a partir de un par de clústers con la 
   distancia entre ellos */
Cluster::Cluster(Cluster cluA, Cluster cluB, double dist) {
    string idA = cluA.a.value().primero();
    string idB = cluB.a.value().primero();
    if (idA < idB)
        a = BinTree<ParData>(ParData(idA + idB, dist/2), cluA.a, cluB.a);
    else
        a = BinTree<ParData>(ParData(idB + idA, dist/2), cluB.a, cluA.a);
}

    	       /*     Lectura y Escritura     */
/* Imprime la estructura arbolescente de un clúster */
void Cluster::imprime_arbol() const {
    if (a.right().empty())
            cout << '[' << a.value().primero() << ']';
    else {
        cout << "[("<< a.value().primero() << ", " << a.value().segundo() << ") ";
        imprime_hojas(a.left());
        imprime_hojas(a.right());
        cout << ']';
    }
}

/* Imprime las hojas de una estructura arbolescente */
void Cluster::imprime_hojas(const BinTree<ParData>& b) const {
    if (not b.empty()) {
        if (b.right().empty()) {
            cout << '[' << b.value().primero() << ']';
        } else {
            cout << "[("<< b.value().primero() << ", " << b.value().segundo() << ") ";
            imprime_hojas(b.left());
            imprime_hojas(b.right());
            cout << ']';
        }
    }
}
