/** @file ParData.cc
    @brief Codigo de la clase ParData.
*/

#include "ParData.hh"

             /*     Constructoras     */
/* Constructora vacía */
ParData::ParData(){
  dist=0;
}

/* Constructora con un identificador y su distancia*/
ParData::ParData(string a, double b) {
  id=a; dist=b;
}

    	       /*     Consultoras     */
/* Devuelve el identificador */
string ParData::primero() const {
  return id;
}

/* Devuelve la distancia */
double ParData::segundo() const {
  return dist;
}
