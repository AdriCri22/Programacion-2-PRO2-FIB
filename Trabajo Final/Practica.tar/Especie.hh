/** @file Especie.hh
    @brief Especificación de la clase Especie
*/

#ifndef ESP_HH
#define ESP_HH

#ifndef NO_DIAGRAM
#include <map>
#include<iostream>
using namespace std;
#endif

/*
 * Clase Especie
 */

/** @class Especie
    @brief Representa una especie con un gen y sus k-meros.
    
    Sus operaciones crean una especie vacía o con un gen que da paso a
    el cálculo del kmero a partir del parámetro k, la consultora del gen
    de la especie y la del cálculo de la distancia entre 2 especies.
*/

class Especie {
    /* Descripción: contiene el gen y los k-meros de una especie */

private:
    /* Una especie se representa mediante un string del gen y un map de 
     k-meros */
    
             /*     Variables privadas     */
    /** @brief int que contiene el parámetro k para la construcción del 
                k-mero*/
    int k;
    
    /** @brief string que contiene el gen de la especie.*/
    string gen;

    /** @brief map de los k-meros de la especie.*/
    map<string, int> kmer;

public:
             /*     Constructoras     */
    /** @brief Constructora vacía.
        \pre Cierto.
        \post Crea una especie vacía.
    */
    Especie();

    /** @brief Constructora con gen y parámetro k.
        \pre Cierto.
        \post Crea una especie con un gen y su k-mero.
    */
    Especie(const string& gen, int k);

             /*     Consultoras     */
    /** @brief Devuelve el gen de la especie.
	     \pre Cierto.
       \post Devuelve un string con el gen de la especie.
    */
    string consultar_gen() const;

    /** @brief Devuelve el valor de la distancias entre especies.
	     \pre Cierto.
       \post Devuelve un double de la distancia entre esta especie y otra.
    */
    double opera_kmers(const Especie& esp) const;

private:
                 /*     Funciones privadas     */
    /** @brief Obtiene los k-meros de un conjunto especie.
        \pre Cierto.
        \post Modifica el map kmer de la especie a partir del gen de la     
                Especie.
    */
    static void calcula_kmer(map<string, int>& kmeros, const string& kmero, int param);
    
};
#endif
