/** @file Tabla.cc
    @brief Código de la clase Tabla. 
*/

#include "Tabla.hh"

/* Constructora vacía de la tabla de distancias */
Tabla::Tabla() {}

/* Añade una distancia a la tabla */
void Tabla::agregar_distancia(const string& idA, const string& idB, double dist) {
    mdist[make_pair(idA, idB)] = dist;
}

/* Elimina una distancia de la tabla */
void Tabla::eliminar_distancia(const string& idA, const string& idB) {
    mdist.erase(make_pair(idA, idB));
}

/* Vacía la tabla */
void Tabla::borrar_tabla() {
    mdist.clear();
}

/* Devuelve la distancia entre los dos identificadores dados */
double Tabla::distancia(string idA, string idB) const {
    map<Ids, double>::const_iterator it = mdist.lower_bound(make_pair(idA, idB));
    return it->second;
}

/* Comprueba si la tabla está vacía */
bool Tabla::tabla_vacia() const {
    if (mdist.begin() == mdist.end()) return true;
    else return false;
}

/* Devuelve la distancia mínima de la tabla */
double Tabla::distancia_minima(string& idA, string& idB) const {
    map<Ids, double>::const_iterator it;
    double dist = 0;
    for (it = mdist.begin(); it != mdist.end(); it++) {
        if (it == mdist.begin() or dist > it->second) {
            dist = it->second;
            idA = it->first.first;
            idB = it->first.second;
        }
    }
    return dist;
}

/* Dados los identificadores de la distancia mínima y otro identificador
   actualiza la tabla según el algoritmo WPGMA */
void Tabla::actualiza_distancias(const string& idA, const string& idB, const string& idC) {
    map<Ids, double>::const_iterator itB;
    if (idB < idC)
        itB = mdist.lower_bound(make_pair(idB, idC));
    else if (idB > idC)
        itB = mdist.lower_bound(make_pair(idC, idB));
    map<Ids, double>::const_iterator itA;
    if (idA < idC) {
        itA = mdist.lower_bound(make_pair(idA, idC));
        mdist.insert({make_pair(idA+idB, idC), (itA->second + itB->second) / 2});
    } else if (idA > idC) {
        itA = mdist.lower_bound(make_pair(idC, idA));
        mdist.insert({make_pair(idC, idA+idB), (itA->second + itB->second) / 2});
    }
    mdist.erase(itA);
    mdist.erase(itB);    
}

/* Imprime la tabla de distancias */
void Tabla::imprimir_tabla_distancias() const {
    map<Ids, double>::const_iterator it;
    string id;    
    for (it = mdist.begin(); it != mdist.end(); it++) {
        if (it == mdist.begin()) {
            id = it->first.first;
            cout << id << ':';
        } else if (id != it->first.first) {
            id = it->first.first;
            cout << endl << id << ':';
        }
            cout << ' ' << it->first.second << ' ' << '(' << it->second << ')';
    }
}
