/** @file Cjt_especies.cc
    @brief Código de la clase Cjt_especies.
*/

#include "Cjt_especies.hh"

    		     /*     Funciones privadas     */
/* Añade a la clase Tabla nuevas distancias entre especies */
void Cjt_especies::agregar_distancia(Tabla& tab, const map<string, Especie>& especies, const string& id, const Especie& esp) {
    map<string, Especie>::const_iterator it;
    for (it = especies.begin(); it != especies.end(); it++) {
        /* Comprueba que el primer string del pair sea el menor de ambos */
        if (id < it->first)
            tab.agregar_distancia(id, it->first, esp.opera_kmers(it->second));
        else
            tab.agregar_distancia(it->first, id, esp.opera_kmers(it->second));
    }
}

/* Elimina de la clase Tabla distancias que tienen el identificador dado */
void Cjt_especies::eliminar_distancia(Tabla& tab, const map<string, Especie>& especies, const string& id) {
    map<string, Especie>::const_iterator it;
    for (it = especies.begin(); it != especies.end(); it++) {
        if (id != it->first) {
            if (id < it->first) tab.eliminar_distancia(id, it->first);
            else tab.eliminar_distancia(it->first, id);
        }
    }
}

    		     /*     Funciones públicas     */
             /*     Constructoras     */
/* Crea un conunto de especies vacío */
Cjt_especies::Cjt_especies() {}

    	       /*     Modificadoras     */
/* Obtiene el parámetro k para calcular los k-meros*/
void Cjt_especies::obtener_k() {
    cin >> k;
}

/* Borra el conjunto de clústers actual y traspasa las especies a clúsetrs
   y copia la tabla de distancias */
void Cjt_especies::ini_clusters(Cjt_clusters& cjt_clu) {
    cjt_clu.borra_clusters();
    map<string, Especie>::const_iterator it;
    for (it = mesp.begin(); it != mesp.end(); it++)
        cjt_clu.crea_cluster(it->first);
    cjt_clu.inicializa_distancias(tabla);
}

/* Añade una especie al conjunto con un identificador y un gen */
void Cjt_especies::crea_especie(const string& id, const string& gen) {
    Especie esp = Especie(gen, k);
    agregar_distancia(tabla, mesp, id, esp);
    mesp[id] = esp;
}

/* Elimina la especie del conjunto que coincida con el identificador dado*/
void Cjt_especies::elimina_especie(const string& id) {
    eliminar_distancia(tabla, mesp, id);
    mesp.erase(id);
}

    	       /*     Consultoras     */
/* Devuele el númeor de especies del conjunto */
int Cjt_especies::numero_especies() const {
    return mesp.size();
}

/* Obtiene el gen de una especie del conjunto dado su identificador */
string Cjt_especies::obtener_gen(const string& id) const {
    map<string, Especie>::const_iterator it = mesp.lower_bound(id);
    return it->second.consultar_gen();
}

/* Devuelve la distancia entre dos especies dados sus identificadores */
double Cjt_especies::distancia(const string& idA, const string& idB) const {
    if (idA < idB) return tabla.distancia(idA, idB);
    else return tabla.distancia(idB, idA);
}

/* Comprueba la existencia de una especie en el conjunto */
bool Cjt_especies::exitse_especie(const string& id) const {
    if (mesp.find(id) != mesp.end()) return true;
    else return false;
}

    	       /*     Lectura y Escritura     */
/* Lee un número de especies */               
void Cjt_especies::lee_cjt_especies() {
    mesp.clear();
    tabla.borrar_tabla();
    int n;
    cin >> n;
    int m = 0;
    while (m < n) {
        string id, gen;
        cin >> id >> gen;
        crea_especie(id, gen);
        m++;
    }
}

/* Imprime el conjunto de especies */
void Cjt_especies::imprime_cjt_especies() const {
    map<string, Especie>::const_iterator it;
    for (it = mesp.begin(); it != mesp.end(); it++)
        cout << it->first << ' ' << it->second.consultar_gen() << endl;
}

/* Imprime la tabla de distancias */
void Cjt_especies::tabla_distancias() const {
    map<string, Especie>::const_iterator it = mesp.end();
    /* Si la tabla de distancias no está vacía que la imprima */
    if (not tabla.tabla_vacia()) {
        tabla.imprimir_tabla_distancias();
        it--;
        cout << endl <<  it->first << ':' << endl;
    } 
    /* Si el conjunto de especies no está vacío que imprima la especie que 
       no tiene distancia o que su distancia ya ha salido anteriormente */
    else if (mesp.end() != mesp.begin()) {
        it--;
        cout << it->first << ':' << endl;
    }
}
