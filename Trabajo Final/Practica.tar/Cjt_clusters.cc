/** @file Cjt_clusters.cc
    @brief Código de la clase Cjt_clusters.
*/

#include "Cjt_clusters.hh"

    		     /*     Funciones privadas     */
/* Ejecuta el paso WPGMA, encuentra la distancia mínima y crea un nuevo
   clúster con una combinación de los identificadores y su distancia
   y borra estos.
   Modifica la tabla de distancias acorde con la combinación de los 
   identificadores de la distancia mínima*/
void Cjt_clusters::paso_wpgma(map<string, Cluster>& clus, Tabla& tab) {
    string idA, idB;
    double minDist = tab.distancia_minima(idA, idB);
    map<string, Cluster>::const_iterator itA = clus.lower_bound(idA);
    map<string, Cluster>::const_iterator itB = clus.lower_bound(idB);
    clus.insert({idA + idB, Cluster(itA->second, itB->second, minDist)});
    clus.erase(itA);
    clus.erase(itB);
    tab.eliminar_distancia(idA, idB);
    map<string, Cluster>::const_iterator it;
    for (it = clus.begin(); it != clus.end(); it++) {
        if (idA+idB != it->first)
            tab.actualiza_distancias(idA, idB, it->first);
    }
}

    		     /*     Funciones públicas     */
             /*     Constructoras     */
/* Crea un conjunto de clústers vacío */
Cjt_clusters::Cjt_clusters() {}

    	       /*     Modificadoras     */
/* Borra todo el contenido del map del conjunto clústers */
void Cjt_clusters::borra_clusters() {
    mclu.clear();
}

/* Crea y añade al map del conjunto de clústers un nuevo clúster con el             
   identificador dado y distancia 0 */
void Cjt_clusters::crea_cluster(const string& id) {
    mclu.insert({id, Cluster(id)});
}

/* Copia la tabla de distancias del conjunto de especies */
void Cjt_clusters::inicializa_distancias(const Tabla& tabla_esp) {
    tabla = tabla_esp;
}

/* Ejecuta un solo paso del algoritmo WPGMA */
void Cjt_clusters::ejecuta_paso_wpgma() {
    paso_wpgma(mclu, tabla);
    imprime_distancia_clusters();
}

/* Ejecuta el algoritmo WPGMA hasta que sólo queda un clúster en el 
   conjunto e imprime la estructura arbolescente resultante*/
void Cjt_clusters::imprime_arbol_filogenetico() {
    while (mclu.size() > 1) {
        paso_wpgma(mclu, tabla);
    }
    map<string, Cluster>::const_iterator it = mclu.begin();
    if (it != mclu.end()) {
        it->second.imprime_arbol();
        cout << endl;
    }
}

    	       /*     Consultoras     */
/* Devuelve el número de clústers del conjunto */
int Cjt_clusters::numero_clusters() const {
    return mclu.size();
}
/* Imprime un clúster */
bool Cjt_clusters::imprime_cluster(string id) const {
    //bool que sirve para saber si se ha encontrado el clúster o no
    bool found = false;
    map<string, Cluster>::const_iterator it;
    for (it = mclu.begin(); it != mclu.end() and not found; it++) {
        if (it->first == id) {
            it->second.imprime_arbol();
            found = true;
        }
    }
    return found;
}

    	       /*     Lectura y Escritura     */
/* Imprime la tabla de distancias */
void Cjt_clusters::imprime_distancia_clusters() const {
      map<string, Cluster>::const_iterator it = mclu.end();
    /* Si la tabla de distancias no está vacía que la imprima */
          if (not tabla.tabla_vacia()) {
              tabla.imprimir_tabla_distancias();
              it--;
              cout << endl << it->first << ':' << endl;
          } 
    /* Si el conjunto de clústers no está vacío que imprima el clúster que 
       no tiene distancia o que su distancia ya ha salido anteriormente */
          else if (mclu.end() != mclu.begin()) {
              it--;
              cout << it->first << ':' << endl;
          }
}
