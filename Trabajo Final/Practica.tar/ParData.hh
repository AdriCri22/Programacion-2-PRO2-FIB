/** @file ParData.hh
    @brief Especificación de la clase ParData
*/
#ifndef CLASS_ParData_HH
#define CLASS_ParData_HH

#ifndef NO_DIAGRAM	//No aparece en el diagrama
#include <iostream>
using namespace std;
#endif

/*
 * Clase ParData
 */

/** @class ParData
    @brief Representa el identificador y la distancia de un clúster.
    
    Clase que es usada en la clase Cluster para la estructura arbolescente.
*/

class ParData {
    /* Descripción: contiene el identificador y la distancia de un clúster
                    que será usado para la estructura arbolescente de la
                    clase Cluster */

private:
             /*     Variables privadas     */
  /** @brief string del identificador*/
  string id;

  /** @brief double con la distancia*/
  double dist;

public:
             /*     Constructoras     */
    /** @brief Constructora vacía.
        \pre Cierto.
        \post El resultado es el ParData (nullptr, 0).
    */
    ParData();

    /** @brief Constructora con identificador y distancia.
        \pre Cierto.
        \post El resultado es el ParData (id, dist).
    */
    ParData(string a, double b);

    	       /*     Consultoras     */
    /** @brief Devuelve el identificador.
        \pre Cierto.
        \post Devuelve un string del identificador.
    */
    string primero() const;

    /** @brief Devuelve la distancia.
        \pre Cierto.
        \post Devuelve un double de la distancia.
    */
    double segundo() const;
};
#endif
