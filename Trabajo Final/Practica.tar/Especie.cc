/** @file Especie.cc
    @brief Código de la clase Especie.
*/

#include "Especie.hh"

             /*     Funciones privadas     */
/* Calcula los k-meros de una especie */
void Especie::calcula_kmer(map<string, int>& kmeros, const string& kmero, int param) {
    int size = kmero.length();
    for (int i = 0; i < size + 1 - param; i++) {
        string str;
        for (int j = 0; j < param; j++) str.push_back(kmero[i + j]);
        kmeros[str]++;
    }
}
    		     /*     Funciones públicas     */
             /*     Constructoras     */
/* Constructora de una especie vacía */
Especie::Especie() {}

/* Constructora de una especie a partir de un gen */
Especie::Especie(const string& gen, int k) {
    this->gen = gen;
    this->k = k;
    calcula_kmer(kmer, gen, k);
}

             /*     Consultoras     */
/* Devuelve el gen de la especie */
string Especie::consultar_gen() const {
    return gen;
}

/* Calcula la distancia entre esta y otra especie */
double Especie::opera_kmers(const Especie& esp) const {
    int union_kmer = 0;
    int inter_kmer = 0;
    map<string, int>::const_iterator itA = kmer.begin();
    map<string, int>::const_iterator itB = esp.kmer.begin();
    while (itA != kmer.end() and itB != esp.kmer.end()) {
        /* Si el k-mero es el mísmo comprueba cual exponente es el mayor y 
           lo añade a la unión y el menor lo añade a la intersección */
        if (itA->first == itB->first) {
            if (itA->second < itB->second) {
                union_kmer += itB->second;
                inter_kmer += itA->second;
            } else {
                union_kmer += itA->second;
                inter_kmer += itB->second;
            }
            itA++;
            itB++;
        } 
        /* Si no coinciden los k-meros avanza el iterador con menor k-mero*/
        else if (itA->first > itB->first) {
            union_kmer += itB->second;
            itB++;
        } else {
            union_kmer += itA->second;
            itA++;
        }
    }
    /* En el caso de la unión hay que añadir los k-meros restantes una de 
       las especies */
    while (itA != kmer.end()) {
        union_kmer += itA->second;
        itA++;
    }
    while (itB != esp.kmer.end()) {
        union_kmer += itB->second;
        itB++;
    }

    return (1.0 - (double) inter_kmer / union_kmer) * 100.0;
}
