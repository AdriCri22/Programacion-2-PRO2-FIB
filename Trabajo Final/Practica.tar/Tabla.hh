/** @file Tabla.hh
    @brief Especificación de la clase Tabla
*/
#ifndef CLASS_Tabla_HH
#define CLASS_Tabla_HH

#ifndef NO_DIAGRAM	//No aparece en el diagrama
#include <map>
#include <iostream>
using namespace std;
#endif

/*
 * Clase Tabla
 */

/** @class Tabla
    @brief Representa la tabla de distancias.
    
    Es la tabla de distancias que usan la clase Cjt_especies y Cjt_clusters
    para almacenar las distancias entre individuos. Sus operaciones 
    permiten añadir y eliminar distancias de la tabla, vaciar la tabla, 
    actualizar la tabla al usar el algoritmo WPGMA, obtener la distancia 
    mínima de la tabla, obtener la distancia dados 2 identificadores, 
    comprobar si la tabla está vacía e imprimir la tabla.
*/

class Tabla {
    /* Descripción: contiene la tabla de distancias entre especies 
                   y/o clústers*/

private:
    /* Una tabla de distancias se representa mediante un map con un 
        pair de 2 identificadores y una distancia, */
    
             /*     Variables privadas     */
  /** @brief Pair con identificadores.*/
    typedef pair <string, string> Ids;

  /** @brief Map que contiene las distancias entre especies.*/
    map<Ids, double> mdist;

public:
             /*     Constructoras     */
    /** @brief Constructora vacía.
        \pre Cierto.
        \post El resultado es una tabla de distancias vacía.
    */
    Tabla();

    	       /*     Modificadoras     */

    /** @brief Agrega una distancia a la tabla.
        \pre Cierto.
        \post Agrega una distancia a la tabla de distancias mediante 2
              identificadores y la distancia.
    */
    void agregar_distancia(const string& idA, const string& idB, double dist);

    /** @brief Elimina distancia a la tabla.
        \pre Cierto.
        \post Elimina de la tabla de distancias la distancia entre
              los identificadores.
    */
    void eliminar_distancia(const string& idA, const string& idB);

    /** @brief Vacía la tabla de distancias.
        \pre Cierto.
        \post La tabla de distancias queda vacía
    */
    void borrar_tabla();

    /** @brief Actualiza la tabla de distancias al ejecutar el algoritmo wpgma.
        \pre Cierto.
        \post Actualiza la tabla de distancias fusionando los       
                identificadores dados.
    */
    void actualiza_distancias(const string& idA, const string& idB, const string& idC);

    	       /*     Consultoras     */
    /** @brief Devuelve la distancia mínima de la tabla de distancias.
        \pre Cierto.
        \post Devuelve un double con la distancia mínima de la tabla y      
                da los identificadores de esta.
    */
    double distancia_minima(string& idA, string& idB) const;

    /** @brief Devuelve la distancia entre 2 identificadores.
        \pre Cierto.
        \post Devuelve un double con la distancia entre los identificadores
              dados.
    */
    double distancia(string idA, string idB) const;

    /** @brief Comprueba si la tabla está vacía.
        \pre Cierto.
        \post Devuelve un bool sobre si la tabla está vacía.
    */
    bool tabla_vacia() const;

    	       /*     Lectura y Escritura     */
    /** @brief Imprime la tabla de distancias.
        \pre Cierto.
        \post Imprime la tabla de distancias por el canal estándar.
    */
    void imprimir_tabla_distancias() const;
};
#endif
