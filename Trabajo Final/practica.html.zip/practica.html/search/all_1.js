var searchData=
[
  ['borra_5fclusters',['borra_clusters',['../class_cjt__clusters.html#ac7f5428837bc5afbe0410d3453b785c4',1,'Cjt_clusters']]],
  ['borrar_5ftabla',['borrar_tabla',['../class_tabla.html#a2a1d4e7298ea05416348c0116d350eea',1,'Tabla']]]
];
