var searchData=
[
  ['k',['k',['../class_cjt__especies.html#a57eaad8467ae4fef3aad9407a235bb3c',1,'Cjt_especies']]],
  ['kmer',['kmer',['../class_especie.html#aa438e3e2f785d96c0ac51e83f60a5879',1,'Especie']]]
];
