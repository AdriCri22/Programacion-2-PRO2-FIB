var searchData=
[
  ['actualiza_5fdistancias',['actualiza_distancias',['../class_tabla.html#a64c59b486ea0024d1b094644367ace3c',1,'Tabla']]],
  ['agregar_5fdistancia',['agregar_distancia',['../class_cjt__especies.html#ac57a0a65423327c637a6113b371bb4e1',1,'Cjt_especies::agregar_distancia()'],['../class_tabla.html#af96d4a2648be9f95d753db053e75e4e9',1,'Tabla::agregar_distancia()']]]
];
