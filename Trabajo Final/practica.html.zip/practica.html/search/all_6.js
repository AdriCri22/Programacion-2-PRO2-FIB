var searchData=
[
  ['id',['id',['../class_par_data.html#a078b99abbc6ebef259da6f91c146c032',1,'ParData']]],
  ['ids',['Ids',['../class_tabla.html#a28fd07a710c7d92c004fd96e9e296697',1,'Tabla']]],
  ['imprime_5farbol',['imprime_arbol',['../class_cluster.html#a385449f0464fd904a8d933222f6b9fe9',1,'Cluster']]],
  ['imprime_5farbol_5ffilogenetico',['imprime_arbol_filogenetico',['../class_cjt__clusters.html#a3fa76914729c387649692829cea0ce84',1,'Cjt_clusters']]],
  ['imprime_5fcjt_5fespecies',['imprime_cjt_especies',['../class_cjt__especies.html#aba7f0f935b6e0b8eb38337ad8675fead',1,'Cjt_especies']]],
  ['imprime_5fcluster',['imprime_cluster',['../class_cjt__clusters.html#a42761062c4b66df5f2e1baefee6f74b3',1,'Cjt_clusters']]],
  ['imprime_5fdistancia_5fclusters',['imprime_distancia_clusters',['../class_cjt__clusters.html#a43b6d0238c165cf1bae334b115cd5bbd',1,'Cjt_clusters']]],
  ['imprime_5fhojas',['imprime_hojas',['../class_cluster.html#a625a436fac18f80db1d9ef6f1ac86d13',1,'Cluster']]],
  ['imprimir_5ftabla_5fdistancias',['imprimir_tabla_distancias',['../class_tabla.html#ae66dd3b00146eddf800053f51af2dc07',1,'Tabla']]],
  ['ini_5fclusters',['ini_clusters',['../class_cjt__especies.html#aa386f65020c4a703019c62b4f7e1b38d',1,'Cjt_especies']]],
  ['inicializa_5fdistancias',['inicializa_distancias',['../class_cjt__clusters.html#af06588963839e80f651471eea714c1ab',1,'Cjt_clusters']]]
];
