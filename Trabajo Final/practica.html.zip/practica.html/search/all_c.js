var searchData=
[
  ['pardata',['ParData',['../class_par_data.html',1,'ParData'],['../class_par_data.html#a8da4db7eb19865de4dd06f7d41acc5e3',1,'ParData::ParData()'],['../class_par_data.html#a4e3075ce2d8869110671245c0e0ffc7f',1,'ParData::ParData(string a, double b)']]],
  ['pardata_2ecc',['ParData.cc',['../_par_data_8cc.html',1,'']]],
  ['pardata_2ehh',['ParData.hh',['../_par_data_8hh.html',1,'']]],
  ['paso_5fwpgma',['paso_wpgma',['../class_cjt__clusters.html#aecb83877d6a26c8f35988a718d090538',1,'Cjt_clusters']]],
  ['primero',['primero',['../class_par_data.html#a4d96d2e9f6ffe4090d1855f6fa1fbb4a',1,'ParData']]],
  ['program_2ecc',['program.cc',['../program_8cc.html',1,'']]]
];
