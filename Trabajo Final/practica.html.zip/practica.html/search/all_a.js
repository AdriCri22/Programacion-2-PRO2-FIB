var searchData=
[
  ['numero_5fclusters',['numero_clusters',['../class_cjt__clusters.html#a879476fddd6e6af5a45de515f52b0271',1,'Cjt_clusters']]],
  ['numero_5fespecies',['numero_especies',['../class_cjt__especies.html#ad5fd3fd9893f4fadb886564ce6c7884e',1,'Cjt_especies']]]
];
