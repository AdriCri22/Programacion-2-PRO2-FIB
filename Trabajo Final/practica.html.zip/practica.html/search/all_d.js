var searchData=
[
  ['segundo',['segundo',['../class_par_data.html#a90f7ce17bded35e27f920e4870febcc8',1,'ParData']]]
];
