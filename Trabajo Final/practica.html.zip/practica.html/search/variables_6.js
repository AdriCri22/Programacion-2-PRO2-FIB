var searchData=
[
  ['tabla',['tabla',['../class_cjt__clusters.html#a76d9bcd0d142baf145f73d58b5890de8',1,'Cjt_clusters::tabla()'],['../class_cjt__especies.html#a6d9ca24b6543cca353030b49b52fd395',1,'Cjt_especies::tabla()']]]
];
