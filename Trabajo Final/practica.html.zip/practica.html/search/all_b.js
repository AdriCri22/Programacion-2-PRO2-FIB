var searchData=
[
  ['obtener_5fgen',['obtener_gen',['../class_cjt__especies.html#a71d6eb63313c5393f3b40f34ce12ba46',1,'Cjt_especies']]],
  ['obtener_5fk',['obtener_k',['../class_cjt__especies.html#a4d2ad89c57532225f8f3d34cd9df0e23',1,'Cjt_especies']]],
  ['opera_5fkmers',['opera_kmers',['../class_especie.html#a085088774829dc31b14fb94c9ed5a423',1,'Especie']]]
];
