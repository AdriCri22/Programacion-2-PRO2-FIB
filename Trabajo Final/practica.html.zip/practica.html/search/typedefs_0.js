var searchData=
[
  ['ids',['Ids',['../class_tabla.html#a28fd07a710c7d92c004fd96e9e296697',1,'Tabla']]]
];
